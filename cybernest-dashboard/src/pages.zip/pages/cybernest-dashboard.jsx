import React, { useState, useEffect } from 'react';
import {
  Activity,
  AlertTriangle,
  BarChart3,
  LogOut,
  Menu,
  Shield,
  Smartphone,
  Settings,
  Database,
  CheckCircle2,
  XCircle,
} from 'lucide-react';

export default function CyberNestDashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [liveActivityLines, setLiveActivityLines] = useState([
    '2024-01-15 14:32:18 - Device SM-A725F-023 connected',
    '2024-01-15 14:32:45 - Policy sync completed for 47 devices',
    '2024-01-15 14:33:12 - Battery alert: iPad-Gen7-015 at 12%',
  ]);
  const [activeNav, setActiveNav] = useState('dashboard');
  const [connectionPulse, setConnectionPulse] = useState(true);

  // Simulate live activity log updates
  useEffect(() => {
    const interval = setInterval(() => {
      const events = [
        '2024-01-15 14:34:01 - Device Pixel-6Pro-042 policy enforced',
        '2024-01-15 14:34:22 - Offline: Galaxy-S10-089',
        '2024-01-15 14:34:45 - Sync request from iPad-Air-M1-007',
        '2024-01-15 14:35:03 - Location update received',
        '2024-01-15 14:35:28 - Config push successful - 45/50 devices',
      ];
      const randomEvent = events[Math.floor(Math.random() * events.length)];
      setLiveActivityLines((prev) => [...prev.slice(-8), randomEvent]);
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  // Simulate connection status pulse
  useEffect(() => {
    const pulse = setInterval(() => {
      setConnectionPulse((prev) => !prev);
    }, 2000);
    return () => clearInterval(pulse);
  }, []);

  const metrics = [
    {
      label: 'Total Enrolled',
      value: '50',
      icon: Smartphone,
      trend: '+2',
      trendLabel: 'this week',
    },
    {
      label: 'Active Now',
      value: '47',
      icon: CheckCircle2,
      trend: '+3',
      trendLabel: 'last 24h',
    },
    {
      label: 'Critical Alerts',
      value: '3',
      icon: AlertTriangle,
      trend: '2',
      trendLabel: 'new',
    },
  ];

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
    { id: 'devices', label: 'Devices', icon: Smartphone },
    { id: 'commands', label: 'Commands', icon: Activity },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50 font-sans">
      {/* Minimal grid background */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.02]">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `linear-gradient(0deg, transparent 24%, rgba(51, 65, 85, 0.1) 25%, rgba(51, 65, 85, 0.1) 26%, transparent 27%, transparent 74%, rgba(51, 65, 85, 0.1) 75%, rgba(51, 65, 85, 0.1) 76%, transparent 77%, transparent),
                              linear-gradient(90deg, transparent 24%, rgba(51, 65, 85, 0.1) 25%, rgba(51, 65, 85, 0.1) 26%, transparent 27%, transparent 74%, rgba(51, 65, 85, 0.1) 75%, rgba(51, 65, 85, 0.1) 76%, transparent 77%, transparent)`,
            backgroundSize: '60px 60px',
          }}
        />
      </div>

      <div className="relative flex h-screen overflow-hidden">
        {/* SIDEBAR */}
        <div
          className={`fixed inset-y-0 left-0 z-40 transition-all duration-300 ${
            sidebarOpen ? 'w-56' : 'w-20'
          } bg-slate-900 border-r border-slate-800 flex flex-col`}
        >
          {/* Logo Section */}
          <div className="p-4 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-slate-800 border border-slate-700">
                <Shield className="w-5 h-5 text-cyan-400" />
              </div>
              {sidebarOpen && (
                <div>
                  <h1 className="text-sm font-semibold text-slate-50">CyberNest</h1>
                  <p className="text-xs text-slate-500">MDM Platform</p>
                </div>
              )}
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeNav === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveNav(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-md transition-colors duration-200 text-sm font-medium ${
                    isActive
                      ? 'bg-slate-800 text-cyan-400 border border-slate-700'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                  }`}
                >
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  {sidebarOpen && <span>{item.label}</span>}
                </button>
              );
            })}
          </nav>

          {/* Logout */}
          {sidebarOpen && (
            <div className="p-4 border-t border-slate-800">
              <button className="w-full flex items-center gap-3 px-4 py-2.5 rounded-md text-slate-400 hover:text-red-400 hover:bg-red-900/20 transition-colors text-sm font-medium">
                <LogOut className="w-4 h-4" />
                <span>Logout</span>
              </button>
            </div>
          )}
        </button>

        {/* MAIN CONTENT */}
        <div className={`flex-1 flex flex-col transition-all duration-300 ${sidebarOpen ? 'ml-56' : 'ml-20'}`}>
          {/* TOP BAR */}
          <div className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-30">
            <div className="px-8 py-4 flex items-center justify-between">
              <div className="flex items-center gap-4">
                {!sidebarOpen && (
                  <button
                    onClick={() => setSidebarOpen(true)}
                    className="p-2 hover:bg-slate-800 rounded transition-colors"
                  >
                    <Menu className="w-5 h-5 text-slate-400" />
                  </button>
                )}
                <h2 className="text-lg font-semibold text-slate-50">Dashboard</h2>
              </div>

              <div className="flex items-center gap-6">
                {/* Backend Status */}
                <div className="flex items-center gap-2 px-3 py-2 rounded-md bg-slate-800 border border-slate-700">
                  <div
                    className={`w-2 h-2 rounded-full bg-emerald-400 ${
                      connectionPulse ? 'animate-pulse' : ''
                    }`}
                  />
                  <span className="text-xs text-slate-300 font-mono">Backend: Online</span>
                </div>

                {/* Time */}
                <div className="text-xs text-slate-400 font-mono">
                  {new Date().toLocaleTimeString('en-US', {
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: true,
                  })}
                </div>

                {/* Admin */}
                <div className="flex items-center gap-2 pl-6 border-l border-slate-800">
                  <div className="text-right">
                    <p className="text-sm font-medium text-slate-50">Admin</p>
                    <p className="text-xs text-slate-500">Level: ADMIN</p>
                  </div>
                  <div className="w-8 h-8 rounded-md bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-400 font-semibold text-xs">
                    AD
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* PAGE CONTENT */}
          <div className="flex-1 overflow-auto p-8">
            {/* METRIC CARDS - HORIZONTAL ROW */}
            <div className="grid grid-cols-3 gap-6 mb-8">
              {metrics.map((metric, idx) => {
                const Icon = metric.icon;
                const isAlert = metric.label.includes('Alert');
                const isActive = metric.label.includes('Active');

                return (
                  <div
                    key={idx}
                    className="bg-slate-900 border border-slate-800 rounded-lg p-6 cursor-pointer group transform transition-all duration-300 hover:shadow-xl hover:-translate-y-2 hover:border-slate-700"
                    style={{
                      boxShadow: 'none',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.boxShadow = '0 10px 30px rgba(0, 0, 0, 0.5)';
                      e.currentTarget.style.transform = 'translateY(-8px)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.boxShadow = 'none';
                      e.currentTarget.style.transform = 'translateY(0)';
                    }}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="text-sm font-medium text-slate-400 group-hover:text-slate-300 transition-colors">
                          {metric.label}
                        </p>
                        <p className="text-3xl font-bold text-slate-50 mt-2">{metric.value}</p>
                        <p className="text-xs text-slate-500 mt-2 group-hover:text-slate-400 transition-colors">
                          {isAlert ? (
                            <span className="text-red-400">↑ {metric.trend} {metric.trendLabel}</span>
                          ) : isActive ? (
                            <span className="text-emerald-400">↑ {metric.trend} {metric.trendLabel}</span>
                          ) : (
                            <span className="text-cyan-400">↑ {metric.trend} {metric.trendLabel}</span>
                          )}
                        </p>
                      </div>
                      <Icon
                        className={`w-8 h-8 transition-transform duration-300 group-hover:scale-110 ${
                          isAlert
                            ? 'text-red-400'
                            : isActive
                            ? 'text-emerald-400'
                            : 'text-cyan-400'
                        }`}
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* LIVE ACTIVITY TERMINAL */}
            <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
              {/* Header */}
              <div className="px-6 py-4 border-b border-slate-800 bg-slate-900/50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  <h3 className="text-sm font-semibold text-slate-50">Activity Log</h3>
                  <span className="text-xs text-slate-500">(Last 24 hours)</span>
                </div>
              </div>

              {/* Terminal Content */}
              <div className="p-6 font-mono text-sm space-y-3 bg-black/20 max-h-96 overflow-y-auto">
                {liveActivityLines.map((line, idx) => {
                  const isAlert = line.includes('alert') || line.includes('Alert');
                  const isOffline = line.includes('Offline');

                  return (
                    <div
                      key={idx}
                      className={`text-slate-300 ${
                        isAlert || isOffline ? 'text-red-400' : 'text-slate-400'
                      }`}
                    >
                      <span className="text-slate-600">&gt;</span> {line}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* ALERTS SECTION */}
            <div className="mt-8">
              <h3 className="text-sm font-semibold text-slate-50 mb-4">Recent Alerts</h3>
              <div className="space-y-3">
                <div className="bg-slate-900 border border-red-900/50 rounded-lg p-4 flex items-start gap-4">
                  <XCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-slate-50">Device Offline</p>
                    <p className="text-xs text-slate-500 mt-1">
                      SM-A725F-023 has been offline for 2 hours
                    </p>
                  </div>
                  <span className="text-xs text-slate-500">2 hours ago</span>
                </div>

                <div className="bg-slate-900 border border-yellow-900/50 rounded-lg p-4 flex items-start gap-4">
                  <AlertTriangle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-slate-50">Low Battery</p>
                    <p className="text-xs text-slate-500 mt-1">
                      iPad-Gen7-015 battery at 12% - Please charge device
                    </p>
                  </div>
                  <span className="text-xs text-slate-500">15 mins ago</span>
                </div>

                <div className="bg-slate-900 border border-cyan-900/50 rounded-lg p-4 flex items-start gap-4">
                  <Activity className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-slate-50">Policy Sync</p>
                    <p className="text-xs text-slate-500 mt-1">
                      Successfully synced policies to 47/50 devices
                    </p>
                  </div>
                  <span className="text-xs text-slate-500">5 mins ago</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        .scrollbar-thin::-webkit-scrollbar {
          width: 6px;
        }
        .scrollbar-thin::-webkit-scrollbar-thumb {
          background-color: rgb(71, 85, 105);
          border-radius: 3px;
        }
        .scrollbar-thin::-webkit-scrollbar-track {
          background-color: transparent;
        }
      `}</style>
    </div>
  );
}
