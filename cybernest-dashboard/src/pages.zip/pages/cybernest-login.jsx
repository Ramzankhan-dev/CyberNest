import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Shield, Lock, Mail, Eye, EyeOff,
  CheckCircle2, AlertCircle, Loader,
} from 'lucide-react';

const S = {
  page: { minHeight:'100vh', backgroundColor:'#020817', color:'#f8fafc', fontFamily:'sans-serif', display:'flex', flexDirection:'column' },
  gridBg: {
    position:'fixed', inset:0, pointerEvents:'none', opacity:0.02,
    backgroundImage:`linear-gradient(0deg,transparent 24%,rgba(51,65,85,.1) 25%,rgba(51,65,85,.1) 26%,transparent 27%,transparent 74%,rgba(51,65,85,.1) 75%,rgba(51,65,85,.1) 76%,transparent 77%),linear-gradient(90deg,transparent 24%,rgba(51,65,85,.1) 25%,rgba(51,65,85,.1) 26%,transparent 27%,transparent 74%,rgba(51,65,85,.1) 75%,rgba(51,65,85,.1) 76%,transparent 77%)`,
    backgroundSize:'60px 60px',
  },
  header: { borderBottom:'1px solid #1e293b', backgroundColor:'rgba(15,23,42,.5)', backdropFilter:'blur(8px)', position:'sticky', top:0, zIndex:30 },
  headerInner: { maxWidth:'80rem', margin:'0 auto', padding:'1rem 2rem', display:'flex', alignItems:'center', justifyContent:'space-between' },
  iconBox: { padding:'0.5rem', borderRadius:'0.5rem', backgroundColor:'#1e293b', border:'1px solid #334155', display:'flex', alignItems:'center' },
  statusPill: { display:'flex', alignItems:'center', gap:'0.5rem', padding:'0.5rem 1rem', borderRadius:'0.375rem', backgroundColor:'#1e293b', border:'1px solid #334155' },
  main: { flex:1, display:'flex', alignItems:'center', justifyContent:'center', padding:'1rem' },
  card: { width:'100%', maxWidth:'28rem', backgroundColor:'#0f172a', border:'1px solid #1e293b', borderRadius:'0.75rem', padding:'2rem', boxShadow:'0 20px 60px rgba(0,0,0,.5)' },
  label: { display:'block', fontSize:'0.8rem', fontWeight:500, color:'#cbd5e1', marginBottom:'0.5rem', letterSpacing:'0.03em' },
  inputWrap: { position:'relative' },
  inputIcon: { position:'absolute', left:'0.75rem', top:'50%', transform:'translateY(-50%)', color:'#64748b', pointerEvents:'none' },
  input: { width:'100%', paddingLeft:'2.5rem', paddingRight:'1rem', paddingTop:'0.65rem', paddingBottom:'0.65rem', backgroundColor:'#1e293b', border:'1px solid #334155', borderRadius:'0.5rem', fontSize:'0.875rem', color:'#f8fafc', outline:'none', boxSizing:'border-box', transition:'border-color .2s, box-shadow .2s' },
  eyeBtn: { position:'absolute', right:'0.75rem', top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'#64748b', padding:0 },
  errorBox: { padding:'0.75rem', backgroundColor:'rgba(127,29,29,.3)', border:'1px solid #7f1d1d', borderRadius:'0.5rem', display:'flex', alignItems:'flex-start', gap:'0.75rem' },
  row: { display:'flex', alignItems:'center', justifyContent:'space-between', fontSize:'0.875rem' },
  footer: { borderTop:'1px solid #1e293b', backgroundColor:'rgba(15,23,42,.5)', padding:'1rem 0' },
  footerInner: { maxWidth:'80rem', margin:'0 auto', padding:'0 2rem', display:'flex', alignItems:'center', justifyContent:'space-between', fontSize:'0.75rem', color:'#64748b' },
};

export default function Login() {
  const [email, setEmail]               = useState('');
  const [password, setPassword]         = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading]       = useState(false);
  const [error, setError]               = useState('');
  const [pulse, setPulse]               = useState(true);
  const [btnHover, setBtnHover]         = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // Agar pehle se logged in hai toh dashboard pe bhejo
    if (localStorage.getItem('token')) navigate('/cybernest-dashboard');
    const t = setInterval(() => setPulse(p => !p), 2000);
    return () => clearInterval(t);
  }, []);

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');
    if (!email || !password) { setError('Email and password are required'); return; }

    setIsLoading(true);
    try {
      const res  = await fetch(
        'https://prenatal-unpleased-unplug.ngrok-free.dev/api/auth/login',
        {
          method:'POST',
          headers:{ 'Content-Type':'application/json', 'ngrok-skip-browser-warning':'true' },
          body: JSON.stringify({ email, password }),
        }
      );
      const data = await res.json();

      if (res.ok && data.token) {
        // ✅ Token save karo
        localStorage.setItem('token', data.token);
        localStorage.setItem('email', email);
        // ✅ Dashboard pe jao
        navigate('/cybernest-dashboard');
      } else {
        setError(data.message || 'Invalid email or password');
      }
    } catch {
      setError('Connection failed! Backend server check karo.');
    } finally {
      setIsLoading(false);
    }
  };

  /* ✅ Cool Cyber Gradient Button */
  const btnStyle = {
    width:'100%', padding:'0.8rem 1rem', borderRadius:'0.5rem',
    fontSize:'0.9rem', fontWeight:600, letterSpacing:'0.04em',
    cursor: isLoading ? 'not-allowed' : 'pointer',
    display:'flex', alignItems:'center', justifyContent:'center', gap:'0.6rem',
    transition:'all 0.3s ease',
    opacity: isLoading ? 0.7 : 1,
    background: btnHover && !isLoading
      ? 'linear-gradient(135deg, #0891b2 0%, #6366f1 100%)'
      : 'linear-gradient(135deg, #164e63 0%, #312e81 100%)',
    border: btnHover && !isLoading ? '1px solid #22d3ee' : '1px solid #1e40af',
    color:'#f8fafc',
    boxShadow: btnHover && !isLoading
      ? '0 0 24px rgba(34,211,238,0.35), 0 4px 16px rgba(0,0,0,0.4)'
      : '0 2px 8px rgba(0,0,0,0.3)',
    transform: btnHover && !isLoading ? 'translateY(-2px)' : 'translateY(0)',
  };

  const focusInput = e => { e.target.style.borderColor='#22d3ee'; e.target.style.boxShadow='0 0 0 2px rgba(34,211,238,.15)'; };
  const blurInput  = e => { e.target.style.borderColor='#334155'; e.target.style.boxShadow='none'; };

  return (
    <div style={S.page}>
      <div style={S.gridBg} />

      {/* HEADER */}
      <div style={S.header}>
        <div style={S.headerInner}>
          <div style={{ display:'flex', alignItems:'center', gap:'0.75rem' }}>
            <div style={S.iconBox}><Shield size={20} color="#22d3ee" /></div>
            <div>
              <p style={{ fontSize:'1.1rem', fontWeight:600, color:'#f8fafc', margin:0 }}>CyberNest MDM</p>
              <p style={{ fontSize:'0.75rem', color:'#64748b', margin:0 }}>Mobile Device Management Platform</p>
            </div>
          </div>
          <div style={S.statusPill}>
            <div style={{ width:8, height:8, borderRadius:'50%', backgroundColor:'#34d399', animation: pulse ? 'pulse 2s infinite' : 'none' }} />
            <span style={{ fontSize:'0.75rem', color:'#cbd5e1', fontFamily:'monospace' }}>Backend: Online</span>
          </div>
        </div>
      </div>

      {/* MAIN */}
      <div style={S.main}>
        <div style={{ width:'100%', maxWidth:'28rem' }}>
          <div style={S.card}>

            {/* Title */}
            <div style={{ textAlign:'center', marginBottom:'2rem' }}>
              <div style={{ display:'flex', justifyContent:'center', marginBottom:'1rem' }}>
                <div style={{ padding:'1rem', borderRadius:'0.75rem', backgroundColor:'#1e293b', border:'1px solid #334155', display:'inline-flex' }}>
                  <Lock size={28} color="#22d3ee" />
                </div>
              </div>
              <h2 style={{ fontSize:'1.5rem', fontWeight:700, color:'#f8fafc', margin:'0 0 0.5rem' }}>Admin Authorization</h2>
              <p style={{ fontSize:'0.875rem', color:'#64748b', margin:0 }}>Secure access to device management system</p>
            </div>

            {/* Form */}
            <form onSubmit={handleLogin} style={{ display:'flex', flexDirection:'column', gap:'1.2rem' }}>

              {/* Email */}
              <div>
                <label style={S.label}>EMAIL ADDRESS</label>
                <div style={S.inputWrap}>
                  <span style={S.inputIcon}><Mail size={15} /></span>
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                    placeholder="admin@cybernest.com" style={S.input}
                    onFocus={focusInput} onBlur={blurInput} />
                </div>
              </div>

              {/* Password */}
              <div>
                <label style={S.label}>PASSWORD</label>
                <div style={S.inputWrap}>
                  <span style={S.inputIcon}><Lock size={15} /></span>
                  <input type={showPassword ? 'text' : 'password'} value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="••••••••"
                    style={{ ...S.input, paddingRight:'2.5rem' }}
                    onFocus={focusInput} onBlur={blurInput} />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} style={S.eyeBtn}>
                    {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>

              {/* Error */}
              {error && (
                <div style={S.errorBox}>
                  <AlertCircle size={16} color="#f87171" style={{ flexShrink:0, marginTop:2 }} />
                  <p style={{ fontSize:'0.875rem', color:'#f87171', margin:0 }}>{error}</p>
                </div>
              )}

              {/* Remember + Forgot */}
              <div style={S.row}>
                <label style={{ display:'flex', alignItems:'center', gap:'0.5rem', cursor:'pointer', color:'#94a3b8', fontSize:'0.85rem' }}>
                  <input type="checkbox" style={{ width:14, height:14, accentColor:'#0891b2' }} />
                  Remember me
                </label>
                <button type="button" style={{ background:'none', border:'none', cursor:'pointer', color:'#22d3ee', fontSize:'0.85rem' }}>
                  Forgot Password?
                </button>
              </div>

              {/* ✅ COOL BUTTON */}
              <button type="submit" disabled={isLoading} style={btnStyle}
                onMouseEnter={() => setBtnHover(true)}
                onMouseLeave={() => setBtnHover(false)}>
                {isLoading
                  ? <><Loader size={16} style={{ animation:'spin 1s linear infinite' }} /><span>Authenticating...</span></>
                  : <span>🔐 Sign In to Dashboard</span>
                }
              </button>

              {/* Signup link */}
              <p style={{ textAlign:'center', fontSize:'0.85rem', color:'#64748b', margin:0 }}>
                Don't have an account?{' '}
                <span onClick={() => navigate('/signup')}
                  style={{ color:'#22d3ee', cursor:'pointer', fontWeight:500 }}>
                  Sign Up
                </span>
              </p>
            </form>

            {/* Demo Box */}
            <div style={{ marginTop:'1.5rem', padding:'1rem', backgroundColor:'rgba(30,41,59,.5)', border:'1px solid #334155', borderRadius:'0.5rem' }}>
              <p style={{ fontSize:'0.75rem', fontWeight:500, color:'#94a3b8', marginBottom:'0.5rem' }}>Demo Credentials:</p>
              <p style={{ fontSize:'0.75rem', color:'#64748b', fontFamily:'monospace', margin:'2px 0' }}>Email: admin@cybernest.com</p>
              <p style={{ fontSize:'0.75rem', color:'#64748b', fontFamily:'monospace', margin:'2px 0' }}>Password: Admin@123</p>
            </div>

            <p style={{ fontSize:'0.75rem', color:'#475569', textAlign:'center', marginTop:'1.5rem' }}>
              By signing in, you agree to our Terms of Service and Privacy Policy
            </p>
          </div>

          <div style={{ marginTop:'1.5rem', display:'flex', alignItems:'center', justifyContent:'center', gap:'0.5rem', fontSize:'0.75rem', color:'#64748b' }}>
            <CheckCircle2 size={16} color="#34d399" />
            <span>Secure connection established</span>
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <div style={S.footer}>
        <div style={S.footerInner}>
          <span>© 2024 CyberNest MDM. All rights reserved.</span>
          <div style={{ display:'flex', gap:'1rem' }}>
            {['Documentation','Support','Status'].map(l => (
              <button key={l} style={{ background:'none', border:'none', cursor:'pointer', color:'#64748b', fontSize:'0.75rem' }}>{l}</button>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes spin  { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }
      `}</style>
    </div>
  );
}