import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Lock, Mail, User, Eye, EyeOff, CheckCircle2, AlertCircle, Loader } from 'lucide-react';

const S = {
  page: { minHeight:'100vh', backgroundColor:'#020817', color:'#f8fafc', fontFamily:'sans-serif', display:'flex', flexDirection:'column' },
  gridBg: {
    position:'fixed', inset:0, pointerEvents:'none', opacity:0.02,
    backgroundImage:`linear-gradient(0deg,transparent 24%,rgba(51,65,85,.1) 25%,rgba(51,65,85,.1) 26%,transparent 27%,transparent 74%,rgba(51,65,85,.1) 75%,rgba(51,65,85,.1) 76%,transparent 77%),linear-gradient(90deg,transparent 24%,rgba(51,65,85,.1) 25%,rgba(51,65,85,.1) 26%,transparent 27%,transparent 74%,rgba(51,65,85,.1) 75%,rgba(51,65,85,.1) 76%,transparent 77%)`,
    backgroundSize:'60px 60px',
  },
  header: { borderBottom:'1px solid #1e293b', backgroundColor:'rgba(15,23,42,.5)', backdropFilter:'blur(8px)', position:'sticky', top:0, zIndex:30 },
  headerInner: { maxWidth:'80rem', margin:'0 auto', padding:'1rem 2rem', display:'flex', alignItems:'center', justifyContent:'space-between' },
  iconBox: { padding:'0.5rem', borderRadius:'0.5rem', backgroundColor:'#1e293b', border:'1px solid #334155', display:'flex', alignItems:'center' },
  statusPill: { display:'flex', alignItems:'center', gap:'0.5rem', padding:'0.5rem 1rem', borderRadius:'0.375rem', backgroundColor:'#1e293b', border:'1px solid #334155' },
  main: { flex:1, display:'flex', alignItems:'center', justifyContent:'center', padding:'1rem' },
  card: { width:'100%', maxWidth:'28rem', backgroundColor:'#0f172a', border:'1px solid #1e293b', borderRadius:'0.75rem', padding:'2rem', boxShadow:'0 20px 60px rgba(0,0,0,.5)' },
  label: { display:'block', fontSize:'0.8rem', fontWeight:500, color:'#cbd5e1', marginBottom:'0.5rem', letterSpacing:'0.03em' },
  inputWrap: { position:'relative' },
  inputIcon: { position:'absolute', left:'0.75rem', top:'50%', transform:'translateY(-50%)', color:'#64748b', pointerEvents:'none' },
  input: { width:'100%', paddingLeft:'2.5rem', paddingRight:'1rem', paddingTop:'0.65rem', paddingBottom:'0.65rem', backgroundColor:'#1e293b', border:'1px solid #334155', borderRadius:'0.5rem', fontSize:'0.875rem', color:'#f8fafc', outline:'none', boxSizing:'border-box', transition:'border-color .2s, box-shadow .2s' },
  eyeBtn: { position:'absolute', right:'0.75rem', top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'#64748b', padding:0 },
  errorBox: { padding:'0.75rem', backgroundColor:'rgba(127,29,29,.3)', border:'1px solid #7f1d1d', borderRadius:'0.5rem', display:'flex', alignItems:'flex-start', gap:'0.75rem' },
  successBox: { padding:'0.75rem', backgroundColor:'rgba(6,78,59,.3)', border:'1px solid #065f46', borderRadius:'0.5rem', display:'flex', alignItems:'flex-start', gap:'0.75rem' },
  footer: { borderTop:'1px solid #1e293b', backgroundColor:'rgba(15,23,42,.5)', padding:'1rem 0' },
  footerInner: { maxWidth:'80rem', margin:'0 auto', padding:'0 2rem', display:'flex', alignItems:'center', justifyContent:'space-between', fontSize:'0.75rem', color:'#64748b' },
};

export default function Signup() {
  const [name, setName]                 = useState('');
  const [organization_name, setOrganization_name] = useState('');
  const [email, setEmail]               = useState('');
  const [password, setPassword]         = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading]       = useState(false);
  const [error, setError]               = useState('');
  const [success, setSuccess]           = useState('');
  const [pulse, setPulse]               = useState(true);
  const [btnHover, setBtnHover]         = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const t = setInterval(() => setPulse(p => !p), 2000);
    return () => clearInterval(t);
  }, []);

  const handleSignup = async (e) => {
    e.preventDefault();
    setError(''); setSuccess('');

    if (!name || !email || !password) { setError('All fields are required'); return; }
    if (password.length < 6) { setError('Password must be at least 6 characters'); return; }

    setIsLoading(true);
    try {
      const res  = await fetch(
        'https://prenatal-unpleased-unplug.ngrok-free.dev/api/auth/register',
        {
          method: 'POST',
          headers: { 'Content-Type':'application/json', 'ngrok-skip-browser-warning':'true' },
          body: JSON.stringify({ name, organization_name, email, password }),
        }
      );
      const data = await res.json();

      if (res.ok) {
        // ✅ Account ban gaya — login pe bhejo
        setSuccess('Account created! Redirecting to login...');
        setTimeout(() => navigate('/login'), 1500);
      } else {
        setError(data.message || 'Registration failed!');
      }
    } catch {
      setError('Connection failed! check your Backend Server.');
    } finally {
      setIsLoading(false);
    }
  };

  const btnStyle = {
    width:'100%', padding:'0.75rem 1rem', borderRadius:'0.5rem',
    fontSize:'0.9rem', fontWeight:600,
    cursor: isLoading ? 'not-allowed' : 'pointer',
    display:'flex', alignItems:'center', justifyContent:'center', gap:'0.6rem',
    transition:'all 0.3s ease', letterSpacing:'0.04em',
    opacity: isLoading ? 0.7 : 1,
    background: btnHover && !isLoading
      ? 'linear-gradient(135deg, #065f46 0%, #164e63 100%)'
      : 'linear-gradient(135deg, #022c22 0%, #0c2a3a 100%)',
    border: btnHover && !isLoading ? '1px solid #34d399' : '1px solid #1e3a2a',
    color:'#f8fafc',
    boxShadow: btnHover && !isLoading
      ? '0 0 20px rgba(52,211,153,0.3), 0 4px 16px rgba(0,0,0,0.4)'
      : '0 2px 8px rgba(0,0,0,0.3)',
    transform: btnHover && !isLoading ? 'translateY(-1px)' : 'translateY(0)',
  };

  const focusInput  = e => { e.target.style.borderColor='#22d3ee'; e.target.style.boxShadow='0 0 0 2px rgba(34,211,238,.15)'; };
  const blurInput   = e => { e.target.style.borderColor='#334155'; e.target.style.boxShadow='none'; };

  return (
    <div style={S.page}>
      <div style={S.gridBg} />

      {/* HEADER */}
      <div style={S.header}>
        <div style={S.headerInner}>
          <div style={{ display:'flex', alignItems:'center', gap:'0.75rem' }}>
            <div style={S.iconBox}><Shield size={20} color="#22d3ee" /></div>
            <div>
              <p style={{ fontSize:'1.1rem', fontWeight:600, color:'#f8fafc', margin:0 }}>CyberNest MDM</p>
              <p style={{ fontSize:'0.75rem', color:'#64748b', margin:0 }}>Mobile Device Management Platform</p>
            </div>
          </div>
          <div style={S.statusPill}>
            <div style={{ width:8, height:8, borderRadius:'50%', backgroundColor:'#34d399', animation: pulse ? 'pulse 2s infinite' : 'none' }} />
            <span style={{ fontSize:'0.75rem', color:'#cbd5e1', fontFamily:'monospace' }}>Backend: Online</span>
          </div>
        </div>
      </div>

      {/* MAIN */}
      <div style={S.main}>
        <div style={{ width:'100%', maxWidth:'28rem' }}>
          <div style={S.card}>

            {/* Title */}
            <div style={{ textAlign:'center', marginBottom:'2rem' }}>
              <div style={{ display:'flex', justifyContent:'center', marginBottom:'1rem' }}>
                <div style={{ padding:'1rem', borderRadius:'0.75rem', backgroundColor:'#1e293b', border:'1px solid #334155', display:'inline-flex' }}>
                  <Shield size={28} color="#34d399" />
                </div>
              </div>
              <h2 style={{ fontSize:'1.5rem', fontWeight:700, color:'#f8fafc', margin:'0 0 0.5rem' }}>Create Admin Account</h2>
              <p style={{ fontSize:'0.875rem', color:'#64748b', margin:0 }}>Register to manage your device fleet</p>
            </div>

            {/* Form */}
            <form onSubmit={handleSignup} style={{ display:'flex', flexDirection:'column', gap:'1.2rem' }}>

              {/* Name */}
              <div>
                <label style={S.label}>FULL NAME</label>
                <div style={S.inputWrap}>
                  <span style={S.inputIcon}><User size={15} /></span>
                  <input type="text" value={name} onChange={e => setName(e.target.value)}
                    placeholder="Usman Ghani" style={S.input}
                    onFocus={focusInput} onBlur={blurInput} />
                </div>
              </div>

             {/* Organization */}
              <div>
                <label style={S.label}>Organization NAME</label>
                <div style={S.inputWrap}>
                  <span style={S.inputIcon}><User size={15} /></span>
                  <input type="text" value={organization_name} onChange={e => setOrganization_name(e.target.value)}
                    placeholder="Comsats University Islamabad" style={S.input}
                    onFocus={focusInput} onBlur={blurInput} />
                </div>
              </div>
              {/* Email */}
              <div>
                <label style={S.label}>EMAIL ADDRESS</label>
                <div style={S.inputWrap}>
                  <span style={S.inputIcon}><Mail size={15} /></span>
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                    placeholder="admin@cybernest.com" style={S.input}
                    onFocus={focusInput} onBlur={blurInput} />
                </div>
              </div>

              {/* Password */}
              <div>
                <label style={S.label}>PASSWORD</label>
                <div style={S.inputWrap}>
                  <span style={S.inputIcon}><Lock size={15} /></span>
                  <input type={showPassword ? 'text' : 'password'} value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    style={{ ...S.input, paddingRight:'2.5rem' }}
                    onFocus={focusInput} onBlur={blurInput} />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} style={S.eyeBtn}>
                    {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
              </div>

              {/* Error */}
              {error && (
                <div style={S.errorBox}>
                  <AlertCircle size={16} color="#f87171" style={{ flexShrink:0, marginTop:2 }} />
                  <p style={{ fontSize:'0.875rem', color:'#f87171', margin:0 }}>{error}</p>
                </div>
              )}

              {/* Success */}
              {success && (
                <div style={S.successBox}>
                  <CheckCircle2 size={16} color="#34d399" style={{ flexShrink:0, marginTop:2 }} />
                  <p style={{ fontSize:'0.875rem', color:'#34d399', margin:0 }}>{success}</p>
                </div>
              )}

              {/* ✅ COOL GREEN BUTTON */}
              <button type="submit" disabled={isLoading} style={btnStyle}
                onMouseEnter={() => setBtnHover(true)}
                onMouseLeave={() => setBtnHover(false)}>
                {isLoading
                  ? <><Loader size={16} style={{ animation:'spin 1s linear infinite' }} /><span>Creating Account...</span></>
                  : <><span>🛡️ Create Account</span></>
                }
              </button>

              {/* Login Link */}
              <p style={{ textAlign:'center', fontSize:'0.85rem', color:'#64748b', margin:0 }}>
                Already have an account?{' '}
                <span onClick={() => navigate('/login')}
                  style={{ color:'#22d3ee', cursor:'pointer', fontWeight:500 }}>
                  Sign In
                </span>
              </p>
            </form>
          </div>

          <div style={{ marginTop:'1.5rem', display:'flex', alignItems:'center', justifyContent:'center', gap:'0.5rem', fontSize:'0.75rem', color:'#64748b' }}>
            <CheckCircle2 size={16} color="#34d399" />
            <span>Secure connection established</span>
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <div style={S.footer}>
        <div style={S.footerInner}>
          <span>© 2024 CyberNest MDM. All rights reserved.</span>
        </div>
      </div>

      <style>{`
        @keyframes spin  { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }
      `}</style>
    </div>
  );
}